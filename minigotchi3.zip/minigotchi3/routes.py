<!-- File: minigotchi/routes.py -->
```python
from flask import Blueprint, render_template, request, jsonify
from flask_socketio import emit
from .services import (
    scan_service, deauth_service, brute_service,
    list_interfaces_service, status_service
)

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def index():
    return render_template('index.html')

@main_bp.route('/api/scan', methods=['POST'])
def api_scan():
    data = request.get_json() or {}
    if 'interface' not in data:
        return jsonify({'error': 'Missing interface'}), 400
    return jsonify(scan_service(data))

@main_bp.route('/api/deauth', methods=['POST'])
def api_deauth():
    data = request.get_json() or {}
    required = ['interface', 'bssid', 'count', 'interval']
    if not all(data.get(k) is not None for k in required):
        return jsonify({'error': 'Missing parameters'}), 400
    return jsonify(deauth_service(data))

@main_bp.route('/api/brute', methods=['POST'])
def api_brute():
    data = request.get_json() or {}
    required = ['interface', 'ssid', 'bssid', 'wordlist', 'delay']
    if not all(data.get(k) is not None for k in required):
        return jsonify({'error': 'Missing parameters'}), 400
    return jsonify(brute_service(data))

@main_bp.route('/api/interfaces', methods=['POST'])
def api_interfaces():
    # Lists available wireless interfaces
    return jsonify(list_interfaces_service())

@main_bp.route('/api/status', methods=['POST'])
def api_status():
    # Returns uptime, handshakes, AI state
    return jsonify(status_service())